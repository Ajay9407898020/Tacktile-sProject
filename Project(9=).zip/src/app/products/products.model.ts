export interface Products{
    currentDate : Date,
    productId : string,
    productName: string,
    productUnit: string,
    purchaseRate: number,
    saleRate: number,
    productCode: string,
}
export interface User{
  unique_identifier : string;
  firstName : string;
  lastName : string;
  gender : string;
  dob : string;
  emailId : string;
  address?: string;
}

import { Component, Injectable } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatDialogRef } from '@angular/material/dialog';

@Injectable()
export class DialogService {

    constructor(private dialog: MatDialog,
        private dialogRef: MatDialogRef<Component>) { }

    openDialog(component: any) {
        let dialogRef = this.dialog.open(component, {
            hasBackdrop: false
        })

        dialogRef.afterClosed().subscribe(result => {
            if (result !== undefined) {
                return result;
            }
        })
    }

    closeDialog(value: any) {

        // Passing value of the forms
        if (value != null) {

            this.dialogRef.close(value);
        } else {
            return;
        }
    }
}
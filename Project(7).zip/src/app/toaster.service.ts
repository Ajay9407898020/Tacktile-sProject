import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
@Injectable()
export class ToasteredService {

    constructor(private toastr : ToastrService){}

    showSuccess(msg : string) {

        this.toastr.success(msg);
    }
    
    showFailiure(msg : string) {
        
        this.toastr.error(msg);
    }
}